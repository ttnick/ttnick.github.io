#!/usr/bin/env python3

import sys
import os
from gurobipy import *

KR = ["CSWS", "KIX", "BW", "GS"]
BA = ["AE", "MM", "UH", "AA"]
KB = ["DGW", "GH", "BROS", "BC"]
RS = ["JOY", "PD", "CK", "RI"]

T = KR + BA + KB + RS
D = [KR, BA, KB, RS]

teamName = {
        "CSWS": "Can't Score Won't Score",
        "KIX": "Kickersarefirstrounderstoo",
        "BW": "Boerger Wombats",
        "GS": "Gyros Slosths",

        "AE": "Aachen Emperors",
        "MM": "Mormon Manziel",
        "UH": "Uerdingen Hooligans",
        "AA": "Aachen Alcoholics",

        "DGW": "DGW Wolfpack",
        "GH": "Gamehawks24",
        "BROS": "TheBros",
        "BC": "Bonner Crows",

        "JOY": "JoyOf6",
        "PD": "Pittsburgh Dealers",
        "CK": "Coppola Koettbullars",
        "RI": "Ruhrpott Igels",
        }


def teamGetSubDiv(i):
    if i in KR:
        return RS
    if i in BA:
        return KB
    if i in KB:
        return BA
    if i in RS:
        return KR 

n = 14
G = range(1, n+1)

P1 = ["BW", "AE", "DGW", "RI"]
P2 = ["CSWS", "MM", "GH", "PD"]
P3 = ["KIX", "UH", "BROS", "CK"]
P4 = ["GS", "AA", "BC", "JOY"]

P = [P1, P2, P3, P4]

model = Model("KrautBowlVIII")

x = {}
for i in T:
    for j in T:
        if i != j:
            for d in G:
                x[i,j,d] = model.addVar(vtype=GRB.BINARY, name="x_{}_{}_{}".format(i, j, d))

y = {}
for i in T:
    for j in T:
        if i != j:
            y[i,j] = model.addVar(vtype=GRB.BINARY, name="y_{}_{}".format(i, j))

model.setObjective(quicksum(y[i,j] for i in T for j in T if i != j), GRB.MINIMIZE)

# ever team plays every week
for i in T:
    for d in G:
        model.addConstr(quicksum(x[i,j,d] + x[j,i,d] for j in T if i != j) == 1, name="oneOpponent_{}_{}".format(i, d))

# penalty for same match in two consecutive weeks
for i in T:
    for j in T:
        if i != j:
            for d in G[0:-1]:
                model.addConstr(x[i,j,d] + x[j,i,d+1] <= 1 + y[i,j], name="enforcePenalty_{}_{}_{}".format(i, j, d))

# 6 divisional matchups
for i in T:
    for div in D:
        if i in div:
            for j in div:
                if i != j:
                    model.addConstr(quicksum(x[i,j,d] for d in G) == 1, name="divisionalMatchupsHome_{}_{}".format(i, j))
                    model.addConstr(quicksum(x[j,i,d] for d in G) == 1, name="divisionalMatchupsAway_{}_{}".format(i, j))

# 4 subdivisional matchups
for i in T:
    div = teamGetSubDiv(i)
    for j in div:
        model.addConstr(quicksum(x[i,j,d] + x[j,i,d] for d in G) >= 1, name="subdivisionalMatchups_{}_{}_{}".format(i, j, d))

# 2 home 2 away
for i in T:
    div = teamGetSubDiv(i)
    model.addConstr(quicksum(x[i,j,d] for j in div for d in G) >= 2, name="subdivisionalHome_{}".format(i))
    model.addConstr(quicksum(x[j,i,d] for j in div for d in G) >= 2, name="subdivisionalAway_{}".format(i))

# 3 positional matchups
for i in T:
    for pos in P:
        if i in pos:
            for j in pos:
                if i != j:
                    model.addConstr(quicksum(x[i,j,d] + x[j,i,d] for d in G) >= 1, name="positionalMatchups_{}_{}_{}".format(i, j, d))

# positional
for i in T:
    div = teamGetSubDiv(i)
    for pos in P:
        if i in pos:
            for j in pos:
                if i != j and j not in div:
                    model.addConstr(quicksum(x[i,j,d] + x[j,i,d] for d in G) == 2, name="positional_{}_{}".format(i, j))

# in every 3 game span, at least one home game, one away game:
for i in T:
    for d in G[0:-2]:
        model.addConstr(quicksum(x[i,j,d] for j in T if i != j) + quicksum(x[i,j,d+1] for j in T if i != j) + quicksum(x[i,j,d+2] for j in T if i != j) >= 1, name="HomeGames_{}_{}".format(i, d))
        model.addConstr(quicksum(x[j,i,d] for j in T if i != j) + quicksum(x[j,i,d+1] for j in T if i != j) + quicksum(x[j,i,d+2] for j in T if i != j) >= 1, name="AwayGames_{}_{}".format(i, d))

# never two times the same game in same venue
for i in T:
    for j in T:
        if i != j:
            model.addConstr(quicksum(x[i,j,d] for d in G) <= 1, name="sameGameDifferentStadium_{}_{}".format(i, j))

# last two weeks divisional matchups
for i in T:
    for div in D:
        if i in div:
            model.addConstr(quicksum(x[i,j,n-1] + x[j,i,n-1] for j in div if i != j) + quicksum(x[i,j,n] + x[j,i,n] for j in div if i != j) == 2, name="lastTwoWeeks_{}".format(i))

model.optimize()
model.write("model.lp")

# print schedule
schedule = open("schedule", 'w')
for d in G:
    schedule.write("Week {}\n".format(d))
    for i in T:
        for j in T:
            if i != j:
                if x[i,j,d].x == 1:
                    schedule.write("{} vs {}\n".format(i, j))
    schedule.write("\n")
schedule.close()

# print extended schedule
schedule = open("schedulex", 'w')
for d in G:
    schedule.write("Week {}\n".format(d))
    for i in T:
        for j in T:
            if i != j:
                if x[i,j,d].x == 1:
                    schedule.write("{} vs {}\n".format(teamName[i], teamName[j]))
    schedule.write("\n")
schedule.close()

# print scheduleisual schedules
for i in T:
    schedule = open("schedule_{}".format(i), 'w')
    schedule.write("{}'s schedule\n".format(teamName[i]))
    schedule.write("=" * len("{}'s schedule".format(teamName[i])))
    schedule.write("\n")
    for d in G:
        for j in T:
            if i != j:
                if x[i,j,d].x == 1:
                    schedule.write("{}\n".format(j))
                elif x[j,i,d].x == 1:
                    schedule.write("@{}\n".format(j))
    schedule.close()
